class QueueInterface(object):
    
    """This is an 
    interface that defines the implementation of a bag
    """
    
    # Constructor
    def __init__(self, sourceCollection = None) -> None:
        """Sets the initial state of self, which includes the
        contents of sourceCollection, if it’s present."""
        pass
    
    # Mutators 
    def isEmpty(self) -> bool:
        """Returns True if len(self) == 0,
        or False otherwise."""
        return True
 
    def __len__(self):
        """Returns the number of items in self."""
        return 0
 
    def __str__(self):
        """Returns the string representation of self."""
        return ""
 
    def __iter__(self):
        """Supports iteration over a view of self."""
        return None
    def __add__(self, other):
        """Returns a new bag containing the contents
        of self and other."""
        return None
 
    def __eq__(self, other):
        """Returns True if self equals other,
        or False otherwise."""
        return False
     
    def count(self, item):
        """Returns the number of instances of item in self."""
        return 0
 
    
    
    # Accesssors 
    def clear(self) -> None:
        """Makes self become empty."""
        pass
 
    def add(self, item):
        """Adds item to self."""
        pass
 
    def remove(self, item):
        """Precondition: item is in self.
        Raises: KeyError if item in not in self.
        Postcondition: item is removed from self."""
        pass
    
    def pop(self):
        """Remove item from front of self and return the item """
        pass
